class pontos {
  static int valor = 0;

  static aumentaPontos(int quanto) {
    valor += quanto;
  }

  static diminuiPontos(int quanto) {
    valor -= quanto;
  }
}
